.. include:: ../../.github/CONTRIBUTING.rst

.. include:: ../changelog-fragments/README.rst
